import { SURI, normalizeKaku, getSuri, KIKKYO_SCORE } from "./src/data/suri";
import { calcGokaku, GOKAKU_MEANING, kakuToGogyo, judgeSansai } from "./src/data/gokaku";

let ok = true;
const check = (c: boolean, m: string) => { if(!c){console.log("✗ "+m);ok=false;} };

// 81数理の網羅
check(Object.keys(SURI).length===81, `81数すべて存在 (実際:${Object.keys(SURI).length})`);
for(let i=1;i<=81;i++){
  const d = SURI[i];
  check(!!d, `${i}画が存在`);
  if(d){
    check(d.num===i, `${i}画のnum整合`);
    check(d.keywords.length>0 && !!d.summary && !!d.detail, `${i}画の全フィールド`);
    check(["大吉","吉","吉凶混合","凶","大凶"].includes(d.kikkyo), `${i}画の吉凶が正規値`);
  }
}

// 正規化：82→1, 100→19
check(normalizeKaku(82)===1, "82画→1");
check(normalizeKaku(81)===81, "81画→81");
check(normalizeKaku(100)===19, "100画→19");

// 最上吉数の確認
const saijo = Object.values(SURI).filter(d=>d.saijo).map(d=>d.num).sort((a,b)=>a-b);
check(JSON.stringify(saijo)===JSON.stringify([15,16,31,32,33,45,48]), `最上吉数7つ (実際:${saijo})`);

// 五格計算の検証
const g = calcGokaku([3,5],[4,9]); // 山田太郎
check(g.tenkaku===8 && g.jinkaku===9 && g.chikaku===13 && g.gaikaku===12 && g.soukaku===21, "山田太郎の五格");

// 五格の意味5つ
check(GOKAKU_MEANING.length===5, "五格の意味5つ");

// 五行変換
check(kakuToGogyo(1)==="木" && kakuToGogyo(13)==="火" && kakuToGogyo(25)==="土" && kakuToGogyo(7)==="金" && kakuToGogyo(10)==="水", "画数→五行変換");

// 三才配置が全組み合わせで判定可能か（5^3=125通り）
const gogyo = ["木","火","土","金","水"] as const;
let sansaiOk = 0;
for(const t of gogyo) for(const j of gogyo) for(const c of gogyo){
  const r = judgeSansai(t,j,c);
  if(r.pattern && r.summary) sansaiOk++;
}
check(sansaiOk===125, `三才配置125通り (実際:${sansaiOk})`);

// disputed/最上吉数の件数レポート
const disputed = Object.values(SURI).filter(d=>d.disputed).length;
console.log(`\n[参考] 流派差のある数: ${disputed}件 / 最上吉数: ${saijo.length}件`);

console.log(ok ? "\n✓ 全データ検証OK：81数理・五格・三才すべて整合" : "\n✗ 不備あり");
