// ============================================================
// 五格の計算ロジック ＋ 五格の意味
// 熊崎式準拠。霊数（1字の姓・名に補う1）と特殊ケースに対応。
// ============================================================

import { normalizeKaku } from "./suri";

export interface Gokaku {
  tenkaku: number;   // 天格：姓の総画数（家系運）
  jinkaku: number;   // 人格：姓の最後＋名の最初（主運・中年期）
  chikaku: number;   // 地格：名の総画数（初年運）
  gaikaku: number;   // 外格：総格−人格（対人運）
  soukaku: number;   // 総格：姓名すべての合計（晩年運・一生）
}

/**
 * 五格を算出する。
 * @param seiStrokes 姓の各文字の画数（例: 佐藤 → [7, 18]）
 * @param meiStrokes 名の各文字の画数（例: 花子 → [7, 3]）
 *
 * 霊数ルール（熊崎式の主流）:
 *  - 1字姓: 天格・外格の算出時、姓の前に霊数1を補う
 *  - 1字名: 地格・外格の算出時、名の後ろに霊数1を補う
 *  - 人格・総格には霊数を使わない
 */
export function calcGokaku(seiStrokes: number[], meiStrokes: number[]): Gokaku {
  const seiSum = seiStrokes.reduce((a, b) => a + b, 0);
  const meiSum = meiStrokes.reduce((a, b) => a + b, 0);

  // 天格：姓の合計（1字姓は霊数1を加える）
  const tenkaku = seiStrokes.length === 1 ? seiSum + 1 : seiSum;

  // 地格：名の合計（1字名は霊数1を加える）
  const chikaku = meiStrokes.length === 1 ? meiSum + 1 : meiSum;

  // 人格：姓の最後の字＋名の最初の字（霊数なし）
  const jinkaku =
    seiStrokes[seiStrokes.length - 1] + meiStrokes[0];

  // 総格：姓名すべての合計（霊数なし）
  const soukaku = seiSum + meiSum;

  // 外格：総格−人格。ただし1字姓・1字名では霊数を考慮する。
  // 一般化した算出：天格(霊数込)＋地格(霊数込)−人格
  // （姓名が各2字以上のときは soukaku − jinkaku と一致する）
  let gaikaku: number;
  if (seiStrokes.length === 1 && meiStrokes.length === 1) {
    // 1字姓1字名：霊数1+1 を外格とする流派が主流
    gaikaku = 2;
  } else {
    gaikaku = tenkaku + chikaku - jinkaku;
  }

  return {
    tenkaku: normalizeKaku(tenkaku),
    jinkaku: normalizeKaku(jinkaku),
    chikaku: normalizeKaku(chikaku),
    gaikaku: normalizeKaku(gaikaku),
    soukaku: normalizeKaku(soukaku),
  };
}

// ---- 五格それぞれの意味 ----
export interface GokakuMeaning {
  key: keyof Gokaku;
  name: string;
  yomi: string;
  period: string;     // 影響する時期
  meaning: string;    // この格が示すもの
  importance: number; // 重要度（5が最重要）
}

export const GOKAKU_MEANING: GokakuMeaning[] = [
  {
    key: "jinkaku", name: "人格", yomi: "じんかく",
    period: "中年期（主運）",
    meaning: "性格・才能・対人運の中心。五格の中で最も重要とされ、その人の本質を映します。",
    importance: 5,
  },
  {
    key: "soukaku", name: "総格", yomi: "そうかく",
    period: "一生・晩年運",
    meaning: "姓名すべての画数の合計。人生全体の運勢を示し、晩年に向けて色濃く影響します。",
    importance: 4,
  },
  {
    key: "chikaku", name: "地格", yomi: "ちかく",
    period: "初年期（〜青年期）",
    meaning: "幼少から青年期の運勢、体質や恋愛傾向、内面の基礎を表します。",
    importance: 3,
  },
  {
    key: "gaikaku", name: "外格", yomi: "がいかく",
    period: "対人・社会",
    meaning: "人間関係や社会での印象、外から見たあなたや環境の質を表します。",
    importance: 2,
  },
  {
    key: "tenkaku", name: "天格", yomi: "てんかく",
    period: "家系・先祖",
    meaning: "姓から受け継ぐ家系の運。個人の意思では変えられない宿命的な要素で、単体での吉凶はあまり重視しません。",
    importance: 1,
  },
];

// ---- 三才配置（天格・人格・地格の五行の組み合わせ）----
// 各格の画数の下一桁から五行を導く。
// 1,2→木 / 3,4→火 / 5,6→土 / 7,8→金 / 9,0→水
export type Gogyo = "木" | "火" | "土" | "金" | "水";

export function kakuToGogyo(kaku: number): Gogyo {
  const d = kaku % 10;
  if (d === 1 || d === 2) return "木";
  if (d === 3 || d === 4) return "火";
  if (d === 5 || d === 6) return "土";
  if (d === 7 || d === 8) return "金";
  return "水"; // 9, 0
}

export interface SansaiData {
  pattern: string;     // 例 "木木木"
  kikkyo: "吉" | "吉凶混合" | "凶";
  summary: string;
}

// 三才配置の代表的な吉凶傾向（天・人・地の五行関係から）
// 相生（生み合う）が多いほど吉、相剋（剋し合う）が多いほど凶とする一般則。
const SOSEI: Record<Gogyo, Gogyo> = { 木: "火", 火: "土", 土: "金", 金: "水", 水: "木" };

export function judgeSansai(ten: Gogyo, jin: Gogyo, chi: Gogyo): SansaiData {
  const pattern = ten + jin + chi;
  // 人格を中心に、天→人、人→地の関係を見る
  const tenToJin = relation(ten, jin);
  const jinToChi = relation(jin, chi);
  const goodCount = [tenToJin, jinToChi].filter((r) => r === "相生" || r === "比和").length;
  const badCount = [tenToJin, jinToChi].filter((r) => r === "相剋").length;

  let kikkyo: SansaiData["kikkyo"];
  let summary: string;
  if (badCount === 0 && goodCount === 2) {
    kikkyo = "吉";
    summary = "天・人・地が生かし合う、調和のとれた安定した配置。心身ともに恵まれ、力を発揮しやすい運勢です。";
  } else if (badCount === 2) {
    kikkyo = "凶";
    summary = "各格が剋し合いやすい配置。緊張や無理が生じやすいので、休息と周囲の支えを大切にすると安定します。";
  } else {
    kikkyo = "吉凶混合";
    summary = "生かし合う面と緊張する面が混じる配置。バランスを意識することで、持ち味を活かしていけます。";
  }
  return { pattern, kikkyo, summary };
}

function relation(a: Gogyo, b: Gogyo): "相生" | "相剋" | "比和" | "その他" {
  if (a === b) return "比和";
  if (SOSEI[a] === b) return "相生";
  // 相剋: 木→土→水→火→金→木
  const SOKOKU: Record<Gogyo, Gogyo> = { 木: "土", 土: "水", 水: "火", 火: "金", 金: "木" };
  if (SOKOKU[a] === b) return "相剋";
  return "その他";
}
